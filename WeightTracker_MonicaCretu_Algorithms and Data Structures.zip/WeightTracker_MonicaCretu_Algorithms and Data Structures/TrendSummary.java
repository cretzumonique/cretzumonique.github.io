package com.example.weighttracker_monicacretu_projecttwo;

import java.util.List;

/**
 * TrendSummary holds all computed analytics results for display.
 * Produced by AnalyticsManager, consumed by MainActivity.
 * @author Monica Cretu
 * @version 1.0
 */
public class TrendSummary {

    private final String trendDirection;
    private final String trendSummaryText;
    private final double latestRollingAverage;
    private final int    bestStreak;
    private final int    totalEntries;
    private final List<WeightAnalytics.RollingAveragePoint>
            rollingAverageSeries;

    public TrendSummary(
            String trendDirection,
            String trendSummaryText,
            double latestRollingAverage,
            int    bestStreak,
            int    totalEntries,
            List<WeightAnalytics.RollingAveragePoint> series) {
        this.trendDirection       = trendDirection;
        this.trendSummaryText     = trendSummaryText;
        this.latestRollingAverage = latestRollingAverage;
        this.bestStreak           = bestStreak;
        this.totalEntries         = totalEntries;
        this.rollingAverageSeries = series;
    }

    public String getTrendDirection()       { return trendDirection; }
    public String getTrendSummaryText()     { return trendSummaryText; }
    public double getLatestRollingAverage() { return latestRollingAverage; }
    public int    getBestStreak()            { return bestStreak; }
    public int    getTotalEntries()          { return totalEntries; }
    public List<WeightAnalytics.RollingAveragePoint>
    getRollingAverageSeries()         { return rollingAverageSeries; }
}

