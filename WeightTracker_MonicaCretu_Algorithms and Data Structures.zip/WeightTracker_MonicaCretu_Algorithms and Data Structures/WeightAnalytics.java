package com.example.weighttracker_monicacretu_projecttwo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * WeightAnalytics provides the Trend Analysis Engine.
 * Implements 5 algorithms:
 *   1. 7-day sliding window rolling average -- O(n)
 *   2. Trend direction detection
 *   3. Binary search for date-range lookup -- O(log n)
 *   4. Multi-criteria sorting -- O(n log n)
 *   5. Best streak calculator -- O(n)
 * @author Monica Cretu
 * @version 1.0
 */
public class WeightAnalytics {

    // Rolling window size for the rolling average algorithm
    public static final int    ROLLING_WINDOW_SIZE  = 7;

    // Minimum change to classify as Losing or Gaining
    public static final double TREND_THRESHOLD_LBS  = 0.5;

    // Trend direction result constants
    public static final String TREND_LOSING       = "Losing";
    public static final String TREND_GAINING      = "Gaining";
    public static final String TREND_MAINTAINING  = "Maintaining";
    public static final String TREND_INSUFFICIENT = "Insufficient data";

    // Sort order constants
    public static final int SORT_DATE_ASC    = 0;
    public static final int SORT_DATE_DESC   = 1;
    public static final int SORT_WEIGHT_ASC  = 2;
    public static final int SORT_WEIGHT_DESC = 3;

    // Private constructor -- utility class, not instantiated
    private WeightAnalytics() {}

    // ================================================================
    // ALGORITHM 1: 7-DAY ROLLING AVERAGE (Sliding Window -- O(n))
    // ================================================================

    /**
     * Calculates a 7-day rolling average using a sliding window.
     * O(n) time -- running sum avoids re-summing the window each step.
     * Input list must be sorted by date ascending.
     */
    public static List<RollingAveragePoint> calculateRollingAverage(
            List<WeightEntry> entries) {
        List<RollingAveragePoint> result = new ArrayList<>();
        if (entries == null || entries.isEmpty()) return result;

        double runningSum  = 0.0;
        int    windowStart = 0;

        for (int i = 0; i < entries.size(); i++) {
            runningSum += entries.get(i).getWeight();

            // Slide the window forward when it exceeds the max size
            if (i - windowStart + 1 > ROLLING_WINDOW_SIZE) {
                runningSum -= entries.get(windowStart).getWeight();
                windowStart++;
            }

            int    windowSize = i - windowStart + 1;
            double average    = runningSum / windowSize;
            result.add(new RollingAveragePoint(
                    entries.get(i).getDate(), average));
        }
        return result;
    }

    // ================================================================
    // ALGORITHM 2: TREND DETECTION
    // ================================================================

    /**
     * Detects trend direction by comparing first and last entries.
     * Input list must be sorted by date ascending.
     */
    public static String detectTrend(List<WeightEntry> entries) {
        if (entries == null || entries.size() < 2)
            return TREND_INSUFFICIENT;

        double first = entries.get(0).getWeight();
        double last  = entries.get(entries.size() - 1).getWeight();
        double delta = last - first;

        if      (delta < -TREND_THRESHOLD_LBS) return TREND_LOSING;
        else if (delta >  TREND_THRESHOLD_LBS) return TREND_GAINING;
        else                                   return TREND_MAINTAINING;
    }

    /**
     * Returns a human-readable trend summary string.
     * Example: "Losing (down 12.5 lbs overall)"
     */
    public static String getTrendSummary(List<WeightEntry> entries) {
        if (entries == null || entries.size() < 2)
            return "Not enough data to calculate trend.";

        String trend       = detectTrend(entries);
        double first       = entries.get(0).getWeight();
        double last        = entries.get(entries.size()-1).getWeight();
        double totalChange = Math.abs(last - first);

        if (trend.equals(TREND_MAINTAINING))
            return String.format(
                    "Maintaining (change of %.1f lbs overall)", totalChange);

        String dir = trend.equals(TREND_LOSING) ? "down" : "up";
        return String.format("%s (%s %.1f lbs overall)",
                trend, dir, totalChange);
    }

    // ================================================================
    // ALGORITHM 3: BINARY SEARCH FOR DATE-RANGE LOOKUP -- O(log n)
    // ================================================================

    /**
     * Binary search for first entry with date >= targetDate.
     * O(log n) -- eliminates half the search space each step.
     * List must be sorted by date ascending.
     * Uses mid = low + (high-low)/2 to avoid integer overflow.
     */
    public static int binarySearchByDate(
            List<WeightEntry> entries, String targetDate) {
        if (entries == null || entries.isEmpty()) return -1;

        int low    = 0;
        int high   = entries.size() - 1;
        int result = entries.size();

        while (low <= high) {
            int mid     = low + (high - low) / 2;
            int compare = entries.get(mid).getDate()
                    .compareTo(targetDate);

            if (compare == 0) {
                result = mid;
                high   = mid - 1; // keep searching left for first match
            } else if (compare < 0) {
                low    = mid + 1; // target is in right half
            } else {
                result = mid;
                high   = mid - 1; // target is in left half
            }
        }
        return result;
    }

    /**
     * Returns all entries within a date range using binary search
     * to locate the start boundary in O(log n), then collects
     * matching entries in O(k) where k = number of results.
     */
    public static List<WeightEntry> getEntriesInDateRange(
            List<WeightEntry> entries,
            String startDate, String endDate) {
        List<WeightEntry> result = new ArrayList<>();
        if (entries == null || entries.isEmpty()) return result;

        int startIndex = binarySearchByDate(entries, startDate);
        if (startIndex < 0 || startIndex >= entries.size())
            return result;

        for (int i = startIndex; i < entries.size(); i++) {
            if (entries.get(i).getDate().compareTo(endDate) <= 0)
                result.add(entries.get(i));
            else
                break; // sorted list -- stop when past endDate
        }
        return result;
    }

    // ================================================================
    // ALGORITHM 4: MULTI-CRITERIA SORTING -- O(n log n)
    // ================================================================

    /**
     * Returns a new sorted copy of entries using the specified order.
     * Uses Java's TimSort (stable, O(n log n) worst case).
     * Returns a new list -- does not modify the input list.
     */
    public static List<WeightEntry> sortEntries(
            List<WeightEntry> entries, int sortOrder) {
        if (entries == null || entries.isEmpty())
            return new ArrayList<>();

        List<WeightEntry> sorted = new ArrayList<>(entries);
        Comparator<WeightEntry> comparator;

        switch (sortOrder) {
            case SORT_DATE_ASC:
                comparator = Comparator.comparing(WeightEntry::getDate);
                break;
            case SORT_DATE_DESC:
                comparator = Comparator.comparing(
                        WeightEntry::getDate).reversed();
                break;
            case SORT_WEIGHT_ASC:
                comparator = Comparator.comparingDouble(
                        WeightEntry::getWeight);
                break;
            case SORT_WEIGHT_DESC:
                comparator = Comparator.comparingDouble(
                        WeightEntry::getWeight).reversed();
                break;
            default:
                throw new IllegalArgumentException(
                        "Unrecognized sort order: " + sortOrder);
        }
        Collections.sort(sorted, comparator);
        return sorted;
    }

    // ================================================================
    // ALGORITHM 5: BEST STREAK CALCULATOR -- O(n)
    // ================================================================

    /**
     * Finds the longest consecutive streak of entries trending
     * toward the goal weight. Single-pass O(n) algorithm.
     * Input list must be sorted by date ascending.
     */
    public static int calculateBestStreak(
            List<WeightEntry> entries, double goalWeight) {
        if (entries == null || entries.size() < 2) return 0;

        // Determine direction: losing or gaining
        boolean isLosingGoal =
                goalWeight < entries.get(0).getWeight();

        int currentStreak = 1;
        int bestStreak    = 1;

        for (int i = 1; i < entries.size(); i++) {
            double prev    = entries.get(i-1).getWeight();
            double current = entries.get(i).getWeight();

            boolean movingTowardGoal = isLosingGoal
                    ? current <= prev
                    : current >= prev;

            if (movingTowardGoal) {
                currentStreak++;
                if (currentStreak > bestStreak)
                    bestStreak = currentStreak;
            } else {
                currentStreak = 1;
            }
        }
        return bestStreak;
    }

    // ================================================================
    // INNER CLASS: RollingAveragePoint
    // ================================================================

    /**
     * Data holder pairing a date with its rolling average value.
     * Returned by calculateRollingAverage as one point in the series.
     */
    public static class RollingAveragePoint {
        private final String date;
        private final double average;

        public RollingAveragePoint(String date, double average) {
            this.date    = date;
            this.average = average;
        }

        public String getDate()    { return date; }
        public double getAverage() { return average; }

        @Override
        public String toString() {
            return String.format(
                    "RollingAveragePoint{date='%s', avg=%.1f}",
                    date, average);
        }
    }
}
