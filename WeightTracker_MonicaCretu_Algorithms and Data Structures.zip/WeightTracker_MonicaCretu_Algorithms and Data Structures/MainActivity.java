package com.example.weighttracker_monicacretu_projecttwo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity -- primary screen of the Weight Tracker app.
 * Milestone Three additions: analytics dashboard panel,
 * sort order Spinner, rawWeightList for in-memory re-sorting,
 * updateAnalyticsDashboard() calling AnalyticsManager pipeline.
 * @author Monica Cretu
 * @version 3.0
 */
public class MainActivity extends AppCompatActivity {

    private static final double MIN_WEIGHT_LBS = 50.0;
    private static final double MAX_WEIGHT_LBS = 700.0;

    // Milestone Two UI
    private RecyclerView recyclerViewWeights;
    private TextView     textGoalWeight;
    private TextView     textCurrentWeight;
    private TextView     textProgressSummary;
    private ProgressBar  progressBarGoal;
    private Button       buttonAddWeight;
    private Button       buttonSetGoal;
    private Button       buttonSmsSettings;

    // Milestone Three UI -- analytics dashboard
    private TextView textTrendDirection;
    private TextView textRollingAverage;
    private TextView textBestStreak;
    private TextView textEntryCount;
    private Spinner  spinnerSortOrder;

    private DatabaseHelper    databaseHelper;
    private WeightAdapter     weightAdapter;
    private List<WeightEntry> weightList;

    // Raw unsorted list -- preserved for in-memory re-sorting
    private List<WeightEntry> rawWeightList;

    // Currently selected sort order
    private int currentSortOrder = WeightAnalytics.SORT_DATE_DESC;

    private boolean dataChanged = true;
    private ActivityResultLauncher<String> smsPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        initDatabase();
        initRecyclerView();
        initSortSpinner();
        initSmsPermissionLauncher();
        initButtonListeners();
        checkSmsPermission();
        loadWeights();
        loadGoalWeight();
        updateProgressDashboard();
        updateAnalyticsDashboard();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (dataChanged) {
            loadWeights();
            loadGoalWeight();
            updateProgressDashboard();
            updateAnalyticsDashboard();
            dataChanged = false;
        }
    }

    private void initViews() {
        recyclerViewWeights  = findViewById(R.id.recyclerViewWeights);
        textGoalWeight       = findViewById(R.id.textGoalWeight);
        textCurrentWeight    = findViewById(R.id.textCurrentWeight);
        textProgressSummary  = findViewById(R.id.textProgressSummary);
        progressBarGoal      = findViewById(R.id.progressBarGoal);
        buttonAddWeight      = findViewById(R.id.buttonAddWeight);
        buttonSetGoal        = findViewById(R.id.buttonSetGoal);
        buttonSmsSettings    = findViewById(R.id.buttonSmsSettings);
        // Milestone Three analytics dashboard
        textTrendDirection   = findViewById(R.id.textTrendDirection);
        textRollingAverage   = findViewById(R.id.textRollingAverage);
        textBestStreak       = findViewById(R.id.textBestStreak);
        textEntryCount       = findViewById(R.id.textEntryCount);
        spinnerSortOrder     = findViewById(R.id.spinnerSortOrder);
    }

    private void initDatabase() {
        databaseHelper = new DatabaseHelper(this);
        weightList     = new ArrayList<>();
        rawWeightList  = new ArrayList<>();
    }

    private void initRecyclerView() {
        weightAdapter = new WeightAdapter(
                weightList, this::deleteWeight, this::editWeight);
        recyclerViewWeights.setLayoutManager(
                new LinearLayoutManager(this));
        recyclerViewWeights.addItemDecoration(new DividerItemDecoration(
                this, DividerItemDecoration.VERTICAL));
        recyclerViewWeights.setAdapter(weightAdapter);
    }

    /**
     * Spinner offers 4 sort orders. When user picks one,
     * re-sorts rawWeightList in memory -- no database query needed.
     */
    private void initSortSpinner() {
        String[] opts = {
                "Date (Newest First)",
                "Date (Oldest First)",
                "Weight (Lightest First)",
                "Weight (Heaviest First)"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, opts);
        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spinnerSortOrder.setAdapter(adapter);
        spinnerSortOrder.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> p,
                                               View v, int pos, long id) {
                        switch (pos) {
                            case 0: currentSortOrder =
                                    WeightAnalytics.SORT_DATE_DESC;   break;
                            case 1: currentSortOrder =
                                    WeightAnalytics.SORT_DATE_ASC;    break;
                            case 2: currentSortOrder =
                                    WeightAnalytics.SORT_WEIGHT_ASC;  break;
                            case 3: currentSortOrder =
                                    WeightAnalytics.SORT_WEIGHT_DESC; break;
                            default: currentSortOrder =
                                    WeightAnalytics.SORT_DATE_DESC;
                        }
                        applySortAndRefresh();
                    }
                    @Override
                    public void onNothingSelected(AdapterView<?> p) {}
                });
    }

    private void initSmsPermissionLauncher() {
        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted)
                        Toast.makeText(this,
                                "SMS notifications enabled",
                                Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(this,
                                "SMS denied. App will work without notifications.",
                                Toast.LENGTH_SHORT).show();
                });
    }

    private void initButtonListeners() {
        buttonAddWeight.setOnClickListener(v -> {
            dataChanged = true;
            startActivity(new Intent(this, AddWeightActivity.class));
        });
        buttonSetGoal.setOnClickListener(v -> {
            dataChanged = true;
            Intent i = new Intent(this, AddWeightActivity.class);
            i.putExtra("mode", "goal");
            startActivity(i);
        });
        buttonSmsSettings.setOnClickListener(v ->
                startActivity(new Intent(this, SmsSettingsActivity.class)));
    }

    /** Loads entries from DB into rawWeightList, then sorts for display. */
    private void loadWeights() {
        rawWeightList.clear();
        Cursor cursor = databaseHelper.getAllWeights();
        if (cursor == null) {
            weightAdapter.updateList(new ArrayList<>());
            return;
        }
        try {
            if (cursor.moveToFirst()) {
                do {
                    int    id     = cursor.getInt(
                            cursor.getColumnIndexOrThrow("id"));
                    String date   = cursor.getString(
                            cursor.getColumnIndexOrThrow("date"));
                    double weight = cursor.getDouble(
                            cursor.getColumnIndexOrThrow("weight"));
                    rawWeightList.add(
                            new WeightEntry(id, date, weight));
                } while (cursor.moveToNext());
            }
        } catch (IllegalArgumentException e) {
            Toast.makeText(this, "Error reading weight data.",
                    Toast.LENGTH_SHORT).show();
        } finally {
            cursor.close();
        }
        applySortAndRefresh();
    }

    /**
     * Sorts rawWeightList with current sort order and updates adapter.
     * No database query -- purely in-memory re-sort.
     */
    private void applySortAndRefresh() {
        List<WeightEntry> sorted = AnalyticsManager.getSortedEntries(
                rawWeightList, currentSortOrder);
        weightAdapter.updateList(sorted);
    }

    private void loadGoalWeight() {
        double goal = databaseHelper.getGoalWeight();
        if (goal != -1)
            textGoalWeight.setText(
                    String.format("Goal Weight: %.1f lbs", goal));
        else
            textGoalWeight.setText("Goal Weight: Not set");
    }

    /** Milestone Two progress dashboard (retained). */
    private void updateProgressDashboard() {
        double goal    = databaseHelper.getGoalWeight();
        double current = databaseHelper.getMostRecentWeight();
        if (current == -1) {
            textCurrentWeight.setText("Current Weight: No entries yet");
            textProgressSummary.setText(
                    "Log your first weight entry to see progress.");
            progressBarGoal.setVisibility(View.GONE);
            return;
        }
        textCurrentWeight.setText(
                String.format("Current Weight: %.1f lbs", current));
        if (goal == -1) {
            textProgressSummary.setText(
                    "Set a goal weight to track your progress.");
            progressBarGoal.setVisibility(View.GONE);
            return;
        }
        double startWeight = databaseHelper.getFirstWeight();
        if (startWeight == -1 || startWeight == goal) {
            progressBarGoal.setVisibility(View.GONE);
            textProgressSummary.setText(
                    "Keep logging to see your progress trend.");
            return;
        }
        double totalChange = Math.abs(startWeight - goal);
        double achieved    = Math.abs(startWeight - current);
        int    pct = (int) Math.min(100,(achieved/totalChange)*100);
        progressBarGoal.setVisibility(View.VISIBLE);
        progressBarGoal.setProgress(pct);
        textProgressSummary.setText(String.format(
                "Progress toward goal: %d%% (%.1f lbs to go)",
                pct, Math.abs(current - goal)));
        if (current <= goal) {
            String phone = databaseHelper.getSmsPhoneNumber();
            if (phone != null && !phone.isEmpty())
                sendGoalReachedSms(phone);
        }
    }

    /**
     * Runs full analytics pipeline via AnalyticsManager and
     * updates the 4 analytics dashboard TextViews.
     */
    private void updateAnalyticsDashboard() {
        double goal = databaseHelper.getGoalWeight();
        TrendSummary s = AnalyticsManager.computeAnalytics(
                rawWeightList, goal);

        // Trend direction with arrow indicator
        String icon;
        switch (s.getTrendDirection()) {
            case WeightAnalytics.TREND_LOSING:
                icon = "down "; break;
            case WeightAnalytics.TREND_GAINING:
                icon = "up ";   break;
            default: icon = "";
        }
        textTrendDirection.setText(
                "Trend: " + icon + s.getTrendSummaryText());

        // 7-day rolling average
        if (s.getLatestRollingAverage() > 0)
            textRollingAverage.setText(String.format(
                    "7-Day Avg: %.1f lbs",
                    s.getLatestRollingAverage()));
        else
            textRollingAverage.setText(
                    "7-Day Avg: Not enough data");

        // Best streak
        if (s.getBestStreak() > 0)
            textBestStreak.setText("Best Streak: "
                    + s.getBestStreak() + " days toward goal");
        else
            textBestStreak.setText(
                    "Best Streak: Set a goal to track streaks");

        // Total entries
        textEntryCount.setText(
                "Total Entries: " + s.getTotalEntries());
    }

    private void deleteWeight(int id) {
        databaseHelper.deleteWeight(id);
        loadWeights();
        updateProgressDashboard();
        updateAnalyticsDashboard();
        Toast.makeText(this, "Entry deleted",
                Toast.LENGTH_SHORT).show();
    }

    private void editWeight(WeightEntry entry) {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Edit Weight Entry");
        b.setMessage(String.format(
                "Current value: %.1f lbs on %s",
                entry.getWeight(), entry.getDate()));
        final EditText input = new EditText(this);
        input.setText(String.valueOf(entry.getWeight()));
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setHint(String.format("Enter weight (%.0f-%.0f lbs)",
                MIN_WEIGHT_LBS, MAX_WEIGHT_LBS));
        b.setView(input);
        b.setPositiveButton("Save", (d, w) -> {
            String s = input.getText().toString().trim();
            if (s.isEmpty()) {
                Toast.makeText(this,
                        "Please enter a weight value.",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            double nw;
            try { nw = Double.parseDouble(s); }
            catch (NumberFormatException e) {
                Toast.makeText(this,
                        "Invalid number.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (nw < MIN_WEIGHT_LBS || nw > MAX_WEIGHT_LBS) {
                Toast.makeText(this, String.format(
                                "Weight must be between %.0f and %.0f lbs.",
                                MIN_WEIGHT_LBS, MAX_WEIGHT_LBS),
                        Toast.LENGTH_SHORT).show();
                return;
            }
            databaseHelper.updateWeight(entry.getId(), nw);
            loadWeights();
            updateProgressDashboard();
            updateAnalyticsDashboard();
            Toast.makeText(this, "Weight updated successfully.",
                    Toast.LENGTH_SHORT).show();
        });
        b.setNegativeButton("Cancel", (d,w) -> d.cancel());
        b.show();
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED)
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    public void sendGoalReachedSms(String phoneNumber) {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) return;
        try {
            SmsManager.getDefault().sendTextMessage(phoneNumber,
                    null, "Congratulations! You reached your goal weight!",
                    null, null);
            Toast.makeText(this, "Goal reached! SMS sent.",
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not send SMS.",
                    Toast.LENGTH_SHORT).show();
        }
    }
}
