package com.example.weighttracker_monicacretu_projecttwo;

import java.util.ArrayList;
import java.util.List;

/**
 * AnalyticsManager orchestrates the analytics pipeline.
 * Accepts raw entry data, runs all algorithms in sequence,
 * returns a TrendSummary ready for display.
 * Pipeline: sort -> rolling average -> trend -> streak -> package
 * @author Monica Cretu
 * @version 1.0
 */
public class AnalyticsManager {

    private AnalyticsManager() {}

    /**
     * Runs the full analytics pipeline and returns a TrendSummary.
     * Safe to call with null or empty list.
     */
    public static TrendSummary computeAnalytics(
            List<WeightEntry> rawEntries, double goalWeight) {

        if (rawEntries == null || rawEntries.isEmpty())
            return buildEmptySummary();

        // Step 1: Sort by date ascending (required for all algorithms)
        List<WeightEntry> sorted = WeightAnalytics.sortEntries(
                rawEntries, WeightAnalytics.SORT_DATE_ASC);

        // Step 2: 7-day rolling average (sliding window O(n))
        List<WeightAnalytics.RollingAveragePoint> series =
                WeightAnalytics.calculateRollingAverage(sorted);

        // Step 3: Extract most recent rolling average for display
        double latestAvg = -1.0;
        if (!series.isEmpty())
            latestAvg = series.get(series.size()-1).getAverage();

        // Step 4: Detect overall trend direction
        String trendDir  = WeightAnalytics.detectTrend(sorted);
        String trendText = WeightAnalytics.getTrendSummary(sorted);

        // Step 5: Best streak toward goal
        int bestStreak = 0;
        if (goalWeight > 0)
            bestStreak = WeightAnalytics.calculateBestStreak(
                    sorted, goalWeight);

        // Step 6: Package all results
        return new TrendSummary(trendDir, trendText, latestAvg,
                bestStreak, sorted.size(), series);
    }

    /**
     * Returns entries in a date range using binary search boundaries.
     */
    public static List<WeightEntry> getEntriesInRange(
            List<WeightEntry> rawEntries,
            String startDate, String endDate) {
        if (rawEntries == null || rawEntries.isEmpty())
            return new ArrayList<>();
        List<WeightEntry> sorted = WeightAnalytics.sortEntries(
                rawEntries, WeightAnalytics.SORT_DATE_ASC);
        return WeightAnalytics.getEntriesInDateRange(
                sorted, startDate, endDate);
    }

    /**
     * Returns a sorted copy of entries in the specified order.
     */
    public static List<WeightEntry> getSortedEntries(
            List<WeightEntry> rawEntries, int sortOrder) {
        return WeightAnalytics.sortEntries(rawEntries, sortOrder);
    }

    private static TrendSummary buildEmptySummary() {
        return new TrendSummary(
                WeightAnalytics.TREND_INSUFFICIENT,
                "Log weight entries to see your trend analysis.",
                -1.0, 0, 0, new ArrayList<>());
    }
}

