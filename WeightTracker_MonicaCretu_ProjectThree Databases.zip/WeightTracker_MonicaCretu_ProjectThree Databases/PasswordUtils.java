package com.example.weighttracker_monicacretu_projecttwo;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * PasswordUtils provides secure password hashing and verification.
 * Replaces plaintext password storage (CWE-256) identified in code review.
 * Uses SHA-256 with a cryptographically secure random salt (SecureRandom).
 * Passwords are never stored in raw form -- only salted hashes.
 * @author Monica Cretu
 * @version 1.0
 */
public class PasswordUtils {

    private static final String HASH_ALGORITHM = "SHA-256";
    private static final int    SALT_BYTES     = 16;
    private static final String DELIMITER      = ":";

    private PasswordUtils() {}

    /**
     * Hashes a plaintext password with a unique random salt.
     * Returns "base64salt:base64hash" -- never the raw password.
     */
    public static String hashPassword(String plainTextPassword) {
        if (plainTextPassword == null || plainTextPassword.isEmpty())
            throw new IllegalArgumentException(
                    "Password must not be null or empty.");
        try {
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[SALT_BYTES];
            random.nextBytes(salt);
            byte[] hash = computeHash(plainTextPassword, salt);
            String saltB64 = Base64.getEncoder().encodeToString(salt);
            String hashB64 = Base64.getEncoder().encodeToString(hash);
            return saltB64 + DELIMITER + hashB64;
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    /**
     * Verifies a plaintext password against a stored salted hash.
     * Uses MessageDigest.isEqual for timing-safe comparison.
     */
    public static boolean verifyPassword(
            String plainTextPassword, String storedHash) {
        if (plainTextPassword == null || plainTextPassword.isEmpty())
            return false;
        if (storedHash == null || !storedHash.contains(DELIMITER))
            return false;
        try {
            String[] parts    = storedHash.split(DELIMITER, 2);
            byte[]   salt     = Base64.getDecoder().decode(parts[0]);
            byte[]   expected = Base64.getDecoder().decode(parts[1]);
            byte[]   actual   = computeHash(plainTextPassword, salt);
            return MessageDigest.isEqual(expected, actual);
        } catch (NoSuchAlgorithmException | IllegalArgumentException e) {
            return false;
        }
    }

    /**
     * Returns true if storedValue appears to be plaintext
     * (does not contain the salt:hash delimiter).
     * Used for transparent migration of pre-upgrade passwords.
     */
    public static boolean isPlaintext(String storedValue) {
        if (storedValue == null) return true;
        return !storedValue.contains(DELIMITER);
    }

    private static byte[] computeHash(String password, byte[] salt)
            throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
        digest.update(salt);
        return digest.digest(password.getBytes());
    }
}

