package com.example.weighttracker_monicacretu_projecttwo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * SecurityAudit documents all security vulnerabilities identified
 * in the Weight Tracker application and mitigations applied.
 * Implements the Vulnerability Assessment Process from CS 405.
 * Demonstrates Course Outcome 5 -- security mindset.
 * @author Monica Cretu
 * @version 1.0
 */
public class SecurityAudit {

    public static final String SEVERITY_CRITICAL = "CRITICAL";
    public static final String SEVERITY_HIGH     = "HIGH";
    public static final String SEVERITY_MEDIUM   = "MEDIUM";
    public static final String SEVERITY_LOW      = "LOW";
    public static final String STATUS_MITIGATED  = "MITIGATED";
    public static final String STATUS_PARTIAL    = "PARTIAL";
    public static final String STATUS_OPEN       = "OPEN";

    private final List<VulnerabilityRecord> records;

    public SecurityAudit() {
        records = new ArrayList<>();
        populateAuditRecords();
    }

    public List<VulnerabilityRecord> getAllRecords() {
        return Collections.unmodifiableList(records);
    }

    public String getSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== WEIGHT TRACKER SECURITY AUDIT ===\n");
        sb.append("Total: ").append(records.size()).append("\n");
        for (VulnerabilityRecord r : records)
            sb.append(String.format("[%s] %s -- %s\n",
                    r.getSeverity(), r.getTitle(), r.getStatus()));
        return sb.toString();
    }

    private void populateAuditRecords() {
        records.add(new VulnerabilityRecord(
                "CWE-256: Plaintext Password Storage",
                SEVERITY_CRITICAL,
                "Passwords stored as plaintext in SQLite users table. " +
                        "Database access exposes all credentials immediately.",
                "Mitigated: PasswordUtils implements SHA-256 hashing with " +
                        "SecureRandom salt. Only salted hash stored. Transparent " +
                        "migration path re-hashes plaintext passwords on first login.",
                STATUS_MITIGATED));
        records.add(new VulnerabilityRecord(
                "CWE-89: SQL Injection via String Concatenation",
                SEVERITY_CRITICAL,
                "getAllWeights() used rawQuery with string concatenation. " +
                        "Pattern could be followed with user-supplied values.",
                "Mitigated: All queries use parameterized selectionArgs. " +
                        "InputValidator screens inputs for injection patterns.",
                STATUS_MITIGATED));
        records.add(new VulnerabilityRecord(
                "CWE-20: Missing Input Validation at Database Layer",
                SEVERITY_HIGH,
                "No validation at database layer. UI values passed directly " +
                        "to database operations without type or range checking.",
                "Mitigated: InputValidator validates all field types. " +
                        "DatabaseHelper calls InputValidator before every operation.",
                STATUS_MITIGATED));
        records.add(new VulnerabilityRecord(
                "CWE-404: Missing Database Error Handling",
                SEVERITY_HIGH,
                "No try-catch around database operations. Failed operations " +
                        "crash the application with no user feedback.",
                "Mitigated: All DatabaseHelper methods wrapped in try-catch. " +
                        "SQLiteException caught and logged. Methods return boolean.",
                STATUS_MITIGATED));
        records.add(new VulnerabilityRecord(
                "CWE-311: Destructive Database Migration",
                SEVERITY_MEDIUM,
                "onUpgrade dropped all tables, destroying user data on " +
                        "any schema version change.",
                "Partially mitigated: onUpgrade uses ALTER TABLE where " +
                        "possible. Full Room migration planned as future enhancement.",
                STATUS_PARTIAL));
        records.add(new VulnerabilityRecord(
                "CWE-476: Null Pointer on Database Cursor",
                SEVERITY_MEDIUM,
                "Cursor objects not null-checked before moveToFirst().",
                "Mitigated: All Cursors null-checked. getColumnIndexOrThrow " +
                        "calls wrapped in try-catch.",
                STATUS_MITIGATED));
        records.add(new VulnerabilityRecord(
                "CWE-312: Sensitive Data in Log Output",
                SEVERITY_LOW,
                "Future debug logging could expose password data in Logcat.",
                "Mitigated: PasswordUtils never logs passwords. " +
                        "Error handling logs only exception class names.",
                STATUS_MITIGATED));
    }

    // ── Inner class: VulnerabilityRecord ──────────────────────────
    public static class VulnerabilityRecord {
        private final String title, severity, description,
                mitigation, status;
        public VulnerabilityRecord(String title, String severity,
                                   String description, String mitigation, String status) {
            this.title = title; this.severity = severity;
            this.description = description;
            this.mitigation = mitigation; this.status = status;
        }
        public String getTitle()       { return title; }
        public String getSeverity()    { return severity; }
        public String getDescription() { return description; }
        public String getMitigation()  { return mitigation; }
        public String getStatus()      { return status; }
    }
}


