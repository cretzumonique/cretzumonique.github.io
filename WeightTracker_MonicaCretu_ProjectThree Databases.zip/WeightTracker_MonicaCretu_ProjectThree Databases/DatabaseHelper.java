package com.example.weighttracker_monicacretu_projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * DatabaseHelper manages all SQLite database operations.
 * Milestone Four enhancements:
 *   - Passwords hashed via PasswordUtils (CWE-256 mitigated)
 *   - Transparent migration: re-hashes plaintext passwords on login
 *   - InputValidator called before all insert/update operations
 *   - try-catch on all database methods (SQLiteException)
 *   - WAL mode and foreign key enforcement enabled
 *   - CHECK constraints on weight columns
 *   - onUpgrade uses ALTER TABLE to preserve user data
 *   - rawQuery replaced with structured db.query() calls
 * @author Monica Cretu
 * @version 4.0
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG              = "DatabaseHelper";
    private static final String DATABASE_NAME    = "WeightTracker.db";
    private static final int    DATABASE_VERSION = 3;

    private static final String TABLE_USERS   = "users";
    private static final String COL_USER_ID   = "id";
    private static final String COL_USERNAME  = "username";
    private static final String COL_PASSWORD  = "password";

    private static final String TABLE_WEIGHTS = "weights";
    private static final String COL_WEIGHT_ID = "id";
    private static final String COL_DATE      = "date";
    private static final String COL_WEIGHT    = "weight";

    private static final String TABLE_GOAL    = "goal_weight";
    private static final String COL_GOAL_ID   = "id";
    private static final String COL_GOAL      = "goal";

    private static final String TABLE_SMS     = "sms_settings";
    private static final String COL_SMS_ID    = "id";
    private static final String COL_SMS_PHONE = "phone_number";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL("PRAGMA journal_mode=WAL");
            db.execSQL("PRAGMA foreign_keys=ON");
            db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                    + COL_USER_ID  + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COL_USERNAME + " TEXT NOT NULL UNIQUE, "
                    + COL_PASSWORD + " TEXT NOT NULL)");
            db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " ("
                    + COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COL_DATE      + " TEXT NOT NULL, "
                    + COL_WEIGHT    + " REAL NOT NULL "
                    + "CHECK(" + COL_WEIGHT + " >= 50.0 AND "
                    + COL_WEIGHT + " <= 700.0))");
            db.execSQL("CREATE TABLE " + TABLE_GOAL + " ("
                    + COL_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COL_GOAL    + " REAL NOT NULL "
                    + "CHECK(" + COL_GOAL + " >= 50.0 AND "
                    + COL_GOAL + " <= 700.0))");
            db.execSQL("CREATE TABLE " + TABLE_SMS + " ("
                    + COL_SMS_ID    + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COL_SMS_PHONE + " TEXT)");
        } catch (SQLiteException e) {
            Log.e(TAG, "onCreate error: " + e.getClass().getName());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        try {
            if (oldV < 2)
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_SMS
                        + " (" + COL_SMS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + COL_SMS_PHONE + " TEXT)");
            if (oldV < 3) {
                db.execSQL("PRAGMA journal_mode=WAL");
                db.execSQL("PRAGMA foreign_keys=ON");
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "onUpgrade error: " + e.getClass().getName());
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) db.execSQL("PRAGMA foreign_keys=ON");
    }

    // ── USER OPERATIONS ─────────────────────────────────────────

    /**
     * Verifies login credentials with transparent migration:
     * if stored password is plaintext, re-hashes it on successful login.
     */
    public boolean checkUser(String username, String password) {
        if (!InputValidator.validateUsername(username).isValid()
                || !InputValidator.validatePassword(password).isValid())
            return false;
        SQLiteDatabase db = null; Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.query(TABLE_USERS,
                    new String[]{COL_USER_ID, COL_PASSWORD},
                    COL_USERNAME + "=?", new String[]{username},
                    null, null, null);
            if (cursor == null || !cursor.moveToFirst()) return false;
            String stored = cursor.getString(
                    cursor.getColumnIndexOrThrow(COL_PASSWORD));
            int userId = cursor.getInt(
                    cursor.getColumnIndexOrThrow(COL_USER_ID));
            // Transparent migration: re-hash plaintext on first login
            if (PasswordUtils.isPlaintext(stored)) {
                if (stored.equals(password)) {
                    String hashed = PasswordUtils.hashPassword(password);
                    if (hashed != null) upgradePasswordHash(userId, hashed);
                    return true;
                }
                return false;
            }
            return PasswordUtils.verifyPassword(password, stored);
        } catch (SQLiteException | IllegalArgumentException e) {
            Log.e(TAG, "checkUser error: " + e.getClass().getName());
            return false;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public boolean usernameExists(String username) {
        if (!InputValidator.validateUsername(username).isValid())
            return false;
        SQLiteDatabase db = null; Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                    COL_USERNAME + "=?", new String[]{username},
                    null, null, null);
            return cursor != null && cursor.getCount() > 0;
        } catch (SQLiteException e) {
            Log.e(TAG, "usernameExists error: " + e.getClass().getName());
            return false;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    /** Adds new user with hashed password -- never stores plaintext. */
    public boolean addUser(String username, String password) {
        if (!InputValidator.validateUsername(username).isValid()
                || !InputValidator.validatePassword(password).isValid())
            return false;
        String hashed = PasswordUtils.hashPassword(password);
        if (hashed == null) {
            Log.e(TAG, "Password hashing failed."); return false;
        }
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues v = new ContentValues();
            v.put(COL_USERNAME, username);
            v.put(COL_PASSWORD, hashed);
            return db.insert(TABLE_USERS, null, v) != -1;
        } catch (SQLiteException e) {
            Log.e(TAG, "addUser error: " + e.getClass().getName());
            return false;
        }
    }

    private void upgradePasswordHash(int userId, String hashed) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues v = new ContentValues();
            v.put(COL_PASSWORD, hashed);
            db.update(TABLE_USERS, v, COL_USER_ID + "=?",
                    new String[]{String.valueOf(userId)});
        } catch (SQLiteException e) {
            Log.e(TAG, "upgradeHash error: " + e.getClass().getName());
        }
    }

    // ── WEIGHT OPERATIONS ────────────────────────────────────────

    public boolean addWeight(String date, double weight) {
        if (!InputValidator.validateDate(date).isValid()
                || !InputValidator.validateWeight(weight).isValid())
            return false;
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues v = new ContentValues();
            v.put(COL_DATE, date); v.put(COL_WEIGHT, weight);
            return db.insert(TABLE_WEIGHTS, null, v) != -1;
        } catch (SQLiteException e) {
            Log.e(TAG, "addWeight error: " + e.getClass().getName());
            return false;
        }
    }

    public void deleteWeight(int id) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            db.delete(TABLE_WEIGHTS, COL_WEIGHT_ID + "=?",
                    new String[]{String.valueOf(id)});
        } catch (SQLiteException e) {
            Log.e(TAG, "deleteWeight error: " + e.getClass().getName());
        }
    }

    public boolean updateWeight(int id, double newWeight) {
        if (!InputValidator.validateWeight(newWeight).isValid()) return false;
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues v = new ContentValues();
            v.put(COL_WEIGHT, newWeight);
            return db.update(TABLE_WEIGHTS, v, COL_WEIGHT_ID + "=?",
                    new String[]{String.valueOf(id)}) > 0;
        } catch (SQLiteException e) {
            Log.e(TAG, "updateWeight error: " + e.getClass().getName());
            return false;
        }
    }

    public Cursor getAllWeights() {
        SQLiteDatabase db = null;
        try {
            db = this.getReadableDatabase();
            return db.query(TABLE_WEIGHTS, null,
                    null, null, null, null, COL_DATE + " DESC");
        } catch (SQLiteException e) {
            Log.e(TAG, "getAllWeights error: " + e.getClass().getName());
            return null;
        }
    }

    public double getMostRecentWeight() {
        SQLiteDatabase db = null; Cursor c = null;
        try {
            db = this.getReadableDatabase();
            c = db.query(TABLE_WEIGHTS, new String[]{COL_WEIGHT},
                    null, null, null, null, COL_DATE + " DESC", "1");
            if (c != null && c.moveToFirst()) return c.getDouble(0);
        } catch (SQLiteException e) {
            Log.e(TAG, "getMostRecent error: " + e.getClass().getName());
        } finally { if (c != null) c.close(); }
        return -1;
    }

    public double getFirstWeight() {
        SQLiteDatabase db = null; Cursor c = null;
        try {
            db = this.getReadableDatabase();
            c = db.query(TABLE_WEIGHTS, new String[]{COL_WEIGHT},
                    null, null, null, null, COL_DATE + " ASC", "1");
            if (c != null && c.moveToFirst()) return c.getDouble(0);
        } catch (SQLiteException e) {
            Log.e(TAG, "getFirstWeight error: " + e.getClass().getName());
        } finally { if (c != null) c.close(); }
        return -1;
    }

    // ── GOAL OPERATIONS ─────────────────────────────────────────

    public boolean setGoalWeight(double goal) {
        if (!InputValidator.validateWeight(goal).isValid()) return false;
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            db.delete(TABLE_GOAL, null, null);
            ContentValues v = new ContentValues();
            v.put(COL_GOAL, goal);
            return db.insert(TABLE_GOAL, null, v) != -1;
        } catch (SQLiteException e) {
            Log.e(TAG, "setGoal error: " + e.getClass().getName());
            return false;
        }
    }

    public double getGoalWeight() {
        SQLiteDatabase db = null; Cursor c = null;
        try {
            db = this.getReadableDatabase();
            c = db.query(TABLE_GOAL, new String[]{COL_GOAL},
                    null, null, null, null, null);
            if (c != null && c.moveToFirst()) return c.getDouble(0);
        } catch (SQLiteException e) {
            Log.e(TAG, "getGoal error: " + e.getClass().getName());
        } finally { if (c != null) c.close(); }
        return -1;
    }

    // ── SMS OPERATIONS ──────────────────────────────────────────

    public boolean saveSmsPhoneNumber(String phoneNumber) {
        if (!InputValidator.validatePhoneNumber(phoneNumber).isValid())
            return false;
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            db.delete(TABLE_SMS, null, null);
            ContentValues v = new ContentValues();
            v.put(COL_SMS_PHONE, phoneNumber);
            return db.insert(TABLE_SMS, null, v) != -1;
        } catch (SQLiteException e) {
            Log.e(TAG, "saveSms error: " + e.getClass().getName());
            return false;
        }
    }

    public String getSmsPhoneNumber() {
        SQLiteDatabase db = null; Cursor c = null;
        try {
            db = this.getReadableDatabase();
            c = db.query(TABLE_SMS, new String[]{COL_SMS_PHONE},
                    null, null, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (SQLiteException e) {
            Log.e(TAG, "getSms error: " + e.getClass().getName());
        } finally { if (c != null) c.close(); }
        return null;
    }
}

