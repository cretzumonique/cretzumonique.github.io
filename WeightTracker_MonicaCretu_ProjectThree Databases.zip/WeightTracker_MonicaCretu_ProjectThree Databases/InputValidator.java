package com.example.weighttracker_monicacretu_projecttwo;

/**
 * InputValidator provides centralized database input validation.
 * Ensures no invalid or malicious data reaches the database.
 * All methods return a ValidationResult with pass/fail and message.
 * @author Monica Cretu
 * @version 1.0
 */
public class InputValidator {

    public static final double MIN_WEIGHT_LBS   = 50.0;
    public static final double MAX_WEIGHT_LBS   = 700.0;
    public static final int    MIN_USERNAME_LEN = 3;
    public static final int    MAX_USERNAME_LEN = 30;
    public static final int    MIN_PASSWORD_LEN = 6;
    public static final int    MAX_PASSWORD_LEN = 50;
    public static final int    MIN_PHONE_DIGITS = 7;

    // Flags common SQL injection patterns
    private static final String SQL_PATTERN =
            ".*(['\";]|--|/\\*|\\*/|UNION|SELECT|DROP|INSERT|UPDATE|DELETE).*";

    private InputValidator() {}

    public static ValidationResult validateUsername(String username) {
        if (username == null || username.trim().isEmpty())
            return ValidationResult.fail("Username must not be empty.");
        String t = username.trim();
        if (t.length() < MIN_USERNAME_LEN)
            return ValidationResult.fail(
                    "Username must be at least " + MIN_USERNAME_LEN + " characters.");
        if (t.length() > MAX_USERNAME_LEN)
            return ValidationResult.fail(
                    "Username must be " + MAX_USERNAME_LEN + " characters or fewer.");
        if (!t.matches("[a-zA-Z0-9_\\-]+"))
            return ValidationResult.fail(
                    "Username may only contain letters, numbers, underscores, hyphens.");
        if (t.toUpperCase().matches(SQL_PATTERN))
            return ValidationResult.fail("Username contains invalid characters.");
        return ValidationResult.pass();
    }

    public static ValidationResult validatePassword(String password) {
        if (password == null || password.isEmpty())
            return ValidationResult.fail("Password must not be empty.");
        if (password.length() < MIN_PASSWORD_LEN)
            return ValidationResult.fail(
                    "Password must be at least " + MIN_PASSWORD_LEN + " characters.");
        if (password.length() > MAX_PASSWORD_LEN)
            return ValidationResult.fail(
                    "Password must be " + MAX_PASSWORD_LEN + " characters or fewer.");
        return ValidationResult.pass();
    }

    public static ValidationResult validateWeight(double weight) {
        if (Double.isNaN(weight) || Double.isInfinite(weight))
            return ValidationResult.fail("Weight must be a valid number.");
        if (weight < MIN_WEIGHT_LBS || weight > MAX_WEIGHT_LBS)
            return ValidationResult.fail(String.format(
                    "Weight must be between %.0f and %.0f lbs.",
                    MIN_WEIGHT_LBS, MAX_WEIGHT_LBS));
        return ValidationResult.pass();
    }

    public static ValidationResult validateWeightString(
            String weightStr, String fieldName) {
        if (weightStr == null || weightStr.trim().isEmpty())
            return ValidationResult.fail(fieldName + " must not be empty.");
        double value;
        try { value = Double.parseDouble(weightStr.trim()); }
        catch (NumberFormatException e) {
            return ValidationResult.fail(
                    fieldName + ": please enter a valid number.");
        }
        ValidationResult r = validateWeight(value);
        if (!r.isValid()) return r;
        return ValidationResult.passWithValue(value);
    }

    public static ValidationResult validatePhoneNumber(String phone) {
        if (phone == null || phone.trim().isEmpty())
            return ValidationResult.fail("Phone number must not be empty.");
        String digits = phone.replaceAll("[^0-9]", "");
        if (digits.length() < MIN_PHONE_DIGITS)
            return ValidationResult.fail("Please enter a valid phone number.");
        return ValidationResult.pass();
    }

    public static ValidationResult validateDate(String date) {
        if (date == null || date.trim().isEmpty())
            return ValidationResult.fail("Date must not be empty.");
        if (!date.matches("\\d{2}/\\d{2}/\\d{4}"))
            return ValidationResult.fail("Date must be in MM/dd/yyyy format.");
        return ValidationResult.pass();
    }

    // ── Inner class: ValidationResult ────────────────────────────
    public static class ValidationResult {
        private final boolean isValid;
        private final String  errorMessage;
        private final double  value;

        private ValidationResult(boolean v, String msg, double val) {
            this.isValid = v; this.errorMessage = msg; this.value = val;
        }
        public static ValidationResult pass() {
            return new ValidationResult(true, null, 0.0); }
        public static ValidationResult passWithValue(double v) {
            return new ValidationResult(true, null, v); }
        public static ValidationResult fail(String msg) {
            return new ValidationResult(false, msg, 0.0); }
        public boolean isValid()        { return isValid; }
        public String  getErrorMessage() { return errorMessage; }
        public double  getValue()        { return value; }
    }
}

