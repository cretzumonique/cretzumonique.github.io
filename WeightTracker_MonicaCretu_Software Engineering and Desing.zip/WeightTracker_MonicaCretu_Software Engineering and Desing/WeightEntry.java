package com.example.weighttracker_monicacretu_projecttwo;

/**
 * WeightEntry is an immutable data model representing a single weight log record.
 *
 * <p>Each instance corresponds to one row in the {@code weights} table of the
 * SQLite database and holds the row's primary key ID, the date the entry was
 * recorded, and the weight value in pounds.</p>
 *
 * <p>Enhancement notes (CS 499 Milestone Two):
 * <ul>
 *   <li>Added Javadoc to the class, constructor, all getters, and the setter</li>
 *   <li>Added toString() override for easier debugging and logging</li>
 * </ul>
 * </p>
 *
 * @author Monica Cretu
 * @version 2.0
 */
public class WeightEntry {

    /** The unique database primary key for this entry. */
    private final int    id;

    /** The date this entry was recorded, formatted as MM/dd/yyyy. */
    private final String date;

    /** The weight value recorded for this entry, in pounds. */
    private double weight;

    // ── Constructor ───────────────────────────────────────────────────────────

    /**
     * Constructs a new WeightEntry with the specified ID, date, and weight.
     *
     * @param id     the database primary key for this entry
     * @param date   the date string for this entry (expected format: MM/dd/yyyy)
     * @param weight the weight value in pounds
     */
    public WeightEntry(int id, String date, double weight) {
        this.id     = id;
        this.date   = date;
        this.weight = weight;
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    /**
     * Returns the database primary key ID for this entry.
     *
     * @return the unique integer ID
     */
    public int getId() { return id; }

    /**
     * Returns the date this entry was recorded.
     *
     * @return the date string in MM/dd/yyyy format
     */
    public String getDate() { return date; }

    /**
     * Returns the weight value recorded for this entry.
     *
     * @return the weight in pounds
     */
    public double getWeight() { return weight; }

    // ── Setter ────────────────────────────────────────────────────────────────

    /**
     * Updates the weight value for this entry.
     * Used when the user edits an existing entry via the edit dialog in
     * {@link MainActivity}.
     *
     * @param weight the new weight value in pounds
     */
    public void setWeight(double weight) { this.weight = weight; }

    // ── Object Overrides ──────────────────────────────────────────────────────

    /**
     * Returns a human-readable string representation of this entry.
     * Useful for debugging and logging.
     *
     * @return a string in the format "WeightEntry{id=X, date='Y', weight=Z}"
     */
    @Override
    public String toString() {
        return "WeightEntry{"
                + "id=" + id
                + ", date='" + date + '\''
                + ", weight=" + weight
                + '}';
    }
}