package com.example.weighttracker_monicacretu_projecttwo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * AddWeightActivity handles adding a new daily weight entry or setting a goal weight.
 *
 * <p>This activity is launched in two modes:
 * <ul>
 *   <li><strong>Default mode:</strong> user enters a daily weight value</li>
 *   <li><strong>Goal mode:</strong> launched with Intent extra {@code "mode"="goal"},
 *       used when the user wants to update their goal weight</li>
 * </ul>
 * </p>
 *
 * <p>Enhancement notes (CS 499 Milestone Two):
 * <ul>
 *   <li>Added numeric range validation: weight and goal values must be between
 *       {@value #MIN_WEIGHT_LBS} and {@value #MAX_WEIGHT_LBS} pounds</li>
 *   <li>Wrapped Double.parseDouble calls in try-catch for NumberFormatException</li>
 *   <li>Extracted validation into dedicated helper methods</li>
 *   <li>Added Javadoc to all methods</li>
 *   <li>Used String.format for consistent numeric display</li>
 * </ul>
 * </p>
 *
 * @author Monica Cretu
 * @version 2.0
 */
public class AddWeightActivity extends AppCompatActivity {

    // ── Constants ─────────────────────────────────────────────────────────────

    /** Minimum acceptable weight or goal value in pounds. */
    private static final double MIN_WEIGHT_LBS = 50.0;

    /** Maximum acceptable weight or goal value in pounds. */
    private static final double MAX_WEIGHT_LBS = 700.0;

    // ── UI Components ─────────────────────────────────────────────────────────

    private EditText       editWeight;
    private EditText       editGoalWeight;
    private TextView       textTodayDate;
    private Button         buttonSaveWeight;
    private Button         buttonCancel;
    private DatabaseHelper databaseHelper;

    /** The date string for today, formatted as MM/dd/yyyy. */
    private String today;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    /**
     * Initializes the activity, connects UI components, formats today's date,
     * and registers the Save and Cancel button listeners.
     *
     * <p>If the launching intent contains the extra {@code "mode"="goal"},
     * the daily weight field is hidden and only the goal weight field is shown.</p>
     *
     * @param savedInstanceState the previously saved instance state, or null
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        // Connect UI elements
        editWeight       = findViewById(R.id.editWeight);
        editGoalWeight   = findViewById(R.id.editGoalWeight);
        textTodayDate    = findViewById(R.id.textTodayDate);
        buttonSaveWeight = findViewById(R.id.buttonSaveWeight);
        buttonCancel     = findViewById(R.id.buttonCancel);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Format and display today's date
        today = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
                .format(new Date());
        textTodayDate.setText("Today: " + today);

        // Save button — validate and persist entries
        buttonSaveWeight.setOnClickListener(v -> saveEntries());

        // Cancel button — return to previous screen without saving
        buttonCancel.setOnClickListener(v -> finish());
    }

    // ── Save Logic ────────────────────────────────────────────────────────────

    /**
     * Reads and validates user input from both weight fields, then persists
     * any valid entries to the database.
     *
     * <p>Each field is processed independently — a valid daily weight entry
     * is saved even if the goal weight field is empty or invalid, and vice versa.
     * After saving, the activity finishes and returns to the calling screen.</p>
     */
    private void saveEntries() {
        String weightStr = editWeight.getText().toString().trim();
        String goalStr   = editGoalWeight.getText().toString().trim();
        boolean anythingSaved = false;

        // Process daily weight entry
        if (!weightStr.isEmpty()) {
            Double weight = parseAndValidateWeight(weightStr, "Daily weight");
            if (weight != null) {
                databaseHelper.addWeight(today, weight);
                Toast.makeText(this, "Weight saved!", Toast.LENGTH_SHORT).show();
                anythingSaved = true;

                // Check whether goal has been reached
                checkGoalReached(weight);
            }
        }

        // Process goal weight entry
        if (!goalStr.isEmpty()) {
            Double goal = parseAndValidateWeight(goalStr, "Goal weight");
            if (goal != null) {
                databaseHelper.setGoalWeight(goal);
                Toast.makeText(this, "Goal weight saved!", Toast.LENGTH_SHORT).show();
                anythingSaved = true;
            }
        }

        if (!anythingSaved && weightStr.isEmpty() && goalStr.isEmpty()) {
            Toast.makeText(this, "Please enter a weight or goal value.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Return to calling screen
        finish();
    }

    // ── Validation Helpers ────────────────────────────────────────────────────

    /**
     * Parses a weight string and validates it against the acceptable range.
     *
     * @param input     the raw string from the EditText field
     * @param fieldName a human-readable label used in error messages
     * @return the parsed {@code Double} value if valid; {@code null} if parsing
     *         fails or the value is out of range
     */
    private Double parseAndValidateWeight(String input, String fieldName) {
        double value;
        try {
            value = Double.parseDouble(input);
        } catch (NumberFormatException e) {
            Toast.makeText(this,
                    fieldName + ": please enter a valid number.",
                    Toast.LENGTH_SHORT).show();
            return null;
        }

        if (value < MIN_WEIGHT_LBS || value > MAX_WEIGHT_LBS) {
            Toast.makeText(this,
                    String.format("%s must be between %.0f and %.0f lbs.",
                            fieldName, MIN_WEIGHT_LBS, MAX_WEIGHT_LBS),
                    Toast.LENGTH_SHORT).show();
            return null;
        }

        return value;
    }

    /**
     * Checks whether a newly logged weight value meets or falls below the
     * stored goal weight and notifies the user if so.
     *
     * @param weight the newly logged weight value in pounds
     */
    private void checkGoalReached(double weight) {
        double goal = databaseHelper.getGoalWeight();
        if (goal != -1 && weight <= goal) {
            Toast.makeText(this,
                    "Congratulations! You reached your goal weight!",
                    Toast.LENGTH_LONG).show();
        }
    }
}
