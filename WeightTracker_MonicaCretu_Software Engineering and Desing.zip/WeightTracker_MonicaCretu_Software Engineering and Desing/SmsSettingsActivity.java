package com.example.weighttracker_monicacretu_projecttwo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * SmsSettingsActivity allows the user to manage SMS notification preferences
 * for the Weight Tracker application.
 *
 * <p>From this screen, the user can enable or disable the SMS permission,
 * enter and save a phone number to receive goal-reached notifications, and
 * view the current permission status.</p>
 *
 * <p>Enhancement notes (CS 499 Milestone Two):
 * <ul>
 *   <li>Added phone number input field (EditText) so the user can save their
 *       notification number — previously there was no way to store this value</li>
 *   <li>Phone number is persisted to the database via
 *       {@link DatabaseHelper#saveSmsPhoneNumber(String)} so that
 *       {@link MainActivity} can retrieve it automatically when the goal
 *       is reached</li>
 *   <li>Added basic phone number format validation before saving</li>
 *   <li>Pre-populates the phone number field with any previously saved value</li>
 *   <li>Added Javadoc to all methods</li>
 * </ul>
 * </p>
 *
 * @author Monica Cretu
 * @version 2.0
 */
public class SmsSettingsActivity extends AppCompatActivity {

    // ── Constants ─────────────────────────────────────────────────────────────

    /** Minimum digit count for a valid phone number. */
    private static final int MIN_PHONE_DIGITS = 7;

    // ── UI Components ─────────────────────────────────────────────────────────

    private TextView   textSmsStatus;
    private EditText   editPhoneNumber;
    private Button     buttonEnableSms;
    private Button     buttonDisableSms;
    private Button     buttonSavePhone;
    private Button     buttonBack;

    private DatabaseHelper              databaseHelper;
    private ActivityResultLauncher<String> smsPermissionLauncher;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    /**
     * Initializes the activity, connects UI components, registers the SMS
     * permission launcher, pre-populates the saved phone number, and
     * attaches button click listeners.
     *
     * @param savedInstanceState the previously saved instance state, or null
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_settings);

        // Connect UI elements
        textSmsStatus   = findViewById(R.id.textSmsStatus);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        buttonEnableSms  = findViewById(R.id.buttonEnableSms);
        buttonDisableSms = findViewById(R.id.buttonDisableSms);
        buttonSavePhone  = findViewById(R.id.buttonSavePhone);
        buttonBack       = findViewById(R.id.buttonBack);

        databaseHelper = new DatabaseHelper(this);

        // Register permission result launcher
        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), isGranted -> {
                    updateSmsStatus(isGranted);
                    Toast.makeText(this,
                            isGranted ? "SMS notifications enabled"
                                    : "SMS permission denied",
                            Toast.LENGTH_SHORT).show();
                });

        // Pre-populate phone number field with saved value if available
        String savedPhone = databaseHelper.getSmsPhoneNumber();
        if (savedPhone != null && !savedPhone.isEmpty()) {
            editPhoneNumber.setText(savedPhone);
        }

        // Display current permission status
        updateSmsStatus(hasSmsPermission());

        // Enable SMS button
        buttonEnableSms.setOnClickListener(v -> {
            if (!hasSmsPermission()) {
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            } else {
                Toast.makeText(this, "SMS notifications already enabled.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Disable SMS — guide user to system settings since Android
        // does not allow apps to revoke their own permissions programmatically
        buttonDisableSms.setOnClickListener(v ->
                Toast.makeText(this,
                        "To disable, go to Settings > Apps > WeightTracker > Permissions",
                        Toast.LENGTH_LONG).show());

        // Save phone number button
        buttonSavePhone.setOnClickListener(v -> savePhoneNumber());

        // Back button
        buttonBack.setOnClickListener(v -> finish());
    }

    // ── Phone Number Persistence ──────────────────────────────────────────────

    /**
     * Reads the phone number from the input field, validates its format,
     * and saves it to the database via {@link DatabaseHelper#saveSmsPhoneNumber(String)}.
     *
     * <p>Validation rules:
     * <ul>
     *   <li>Field must not be empty</li>
     *   <li>Digits-only count must be at least {@value #MIN_PHONE_DIGITS}</li>
     * </ul>
     * </p>
     */
    private void savePhoneNumber() {
        String phone = editPhoneNumber.getText().toString().trim();

        if (phone.isEmpty()) {
            Toast.makeText(this, "Please enter a phone number.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Count digits only to validate minimum length
        String digitsOnly = phone.replaceAll("[^0-9]", "");
        if (digitsOnly.length() < MIN_PHONE_DIGITS) {
            Toast.makeText(this,
                    "Please enter a valid phone number.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        databaseHelper.saveSmsPhoneNumber(phone);
        Toast.makeText(this, "Phone number saved.", Toast.LENGTH_SHORT).show();
    }

    // ── Permission Helpers ────────────────────────────────────────────────────

    /**
     * Checks whether the SEND_SMS permission is currently granted.
     *
     * @return {@code true} if the permission is granted; {@code false} otherwise
     */
    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Updates the SMS status TextView to reflect the current permission state.
     * Text is colored green when enabled and red when disabled.
     *
     * @param enabled {@code true} if the SMS permission is currently granted
     */
    private void updateSmsStatus(boolean enabled) {
        if (enabled) {
            textSmsStatus.setText("SMS Notifications: ENABLED");
            textSmsStatus.setTextColor(getColor(android.R.color.holo_green_dark));
        } else {
            textSmsStatus.setText("SMS Notifications: DISABLED");
            textSmsStatus.setTextColor(getColor(android.R.color.holo_red_dark));
        }
    }
}