package com.example.weighttracker_monicacretu_projecttwo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/**
 * WeightAdapter connects a list of {@link WeightEntry} objects to the
 * RecyclerView displayed in {@link MainActivity}.
 *
 * <p>Each row displays the date and weight value of one entry, along with
 * Delete and Edit action buttons whose callbacks are provided by the
 * hosting Activity.</p>
 *
 * <p>Enhancement notes (CS 499 Milestone Two):
 * <ul>
 *   <li>Replaced notifyDataSetChanged() with DiffUtil for efficient,
 *       targeted RecyclerView updates — only rows that actually changed
 *       are redrawn, improving UI performance and eliminating full-list
 *       flicker on every data change</li>
 *   <li>Added WeightEntryDiffCallback inner class to define item equality</li>
 *   <li>Added Javadoc to all methods and inner classes</li>
 *   <li>Defensive copy of incoming list to prevent external mutation</li>
 * </ul>
 * </p>
 *
 * @author Monica Cretu
 * @version 2.0
 */
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    // ── Listener Interfaces ───────────────────────────────────────────────────

    /**
     * Callback interface for delete button clicks.
     */
    public interface OnDeleteClickListener {
        /**
         * Called when the user taps the Delete button on a weight row.
         *
         * @param id the database ID of the entry to delete
         */
        void onDeleteClick(int id);
    }

    /**
     * Callback interface for edit button clicks.
     */
    public interface OnEditClickListener {
        /**
         * Called when the user taps the Edit button on a weight row.
         *
         * @param entry the {@link WeightEntry} to be edited
         */
        void onEditClick(WeightEntry entry);
    }

    // ── Fields ────────────────────────────────────────────────────────────────

    private List<WeightEntry>       weightList;
    private final OnDeleteClickListener deleteListener;
    private final OnEditClickListener   editListener;

    // ── Constructor ───────────────────────────────────────────────────────────

    /**
     * Constructs a new WeightAdapter.
     *
     * @param weightList     the initial list of weight entries to display
     * @param deleteListener callback invoked when a delete button is tapped
     * @param editListener   callback invoked when an edit button is tapped
     */
    public WeightAdapter(List<WeightEntry> weightList,
                         OnDeleteClickListener deleteListener,
                         OnEditClickListener editListener) {
        this.weightList     = new ArrayList<>(weightList);
        this.deleteListener = deleteListener;
        this.editListener   = editListener;
    }

    // ── RecyclerView.Adapter Methods ──────────────────────────────────────────

    /**
     * Inflates the item layout and creates a new {@link WeightViewHolder}.
     *
     * @param parent   the parent ViewGroup into which the new view will be added
     * @param viewType the view type of the new view (unused — single view type)
     * @return a new {@link WeightViewHolder} holding the inflated row view
     */
    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_row, parent, false);
        return new WeightViewHolder(view);
    }

    /**
     * Binds the data from the {@link WeightEntry} at the given position to the
     * provided {@link WeightViewHolder}.
     *
     * @param holder   the ViewHolder to update
     * @param position the position of the item in the adapter's data set
     */
    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightList.get(position);
        holder.textDate.setText(entry.getDate());
        holder.textWeight.setText(String.format("%.1f lbs", entry.getWeight()));

        holder.buttonDelete.setOnClickListener(v ->
                deleteListener.onDeleteClick(entry.getId()));

        holder.buttonEdit.setOnClickListener(v ->
                editListener.onEditClick(entry));
    }

    /**
     * Returns the total number of items in the adapter's data set.
     *
     * @return the size of the weight entry list
     */
    @Override
    public int getItemCount() {
        return weightList.size();
    }

    // ── List Update with DiffUtil ─────────────────────────────────────────────

    /**
     * Updates the adapter's data set using {@link DiffUtil} to compute the
     * minimal set of changes between the old and new lists.
     *
     * <p>This replaces the previous {@code notifyDataSetChanged()} call, which
     * forced a full redraw of every visible row on any data change. DiffUtil
     * calculates exactly which items were added, removed, or changed and
     * dispatches only the necessary update events — improving performance and
     * eliminating unnecessary UI flicker.</p>
     *
     * @param newList the updated list of weight entries to display
     */
    public void updateList(List<WeightEntry> newList) {
        List<WeightEntry> oldList = this.weightList;
        List<WeightEntry> updatedList = new ArrayList<>(newList);

        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(
                new WeightEntryDiffCallback(oldList, updatedList));

        this.weightList = updatedList;
        diffResult.dispatchUpdatesTo(this);
    }

    // ── ViewHolder ────────────────────────────────────────────────────────────

    /**
     * WeightViewHolder holds references to the views within a single weight
     * entry row in the RecyclerView.
     */
    static class WeightViewHolder extends RecyclerView.ViewHolder {

        /** Displays the date of the weight entry. */
        TextView textDate;

        /** Displays the weight value in pounds. */
        TextView textWeight;

        /** Button that triggers the delete callback for this entry. */
        Button buttonDelete;

        /** Button that triggers the edit callback for this entry. */
        Button buttonEdit;

        /**
         * Constructs a WeightViewHolder and binds view references.
         *
         * @param itemView the inflated row view for this holder
         */
        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            textDate     = itemView.findViewById(R.id.textDate);
            textWeight   = itemView.findViewById(R.id.textWeight);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
            buttonEdit   = itemView.findViewById(R.id.buttonEdit);
        }
    }

    // ── DiffUtil Callback ─────────────────────────────────────────────────────

    /**
     * WeightEntryDiffCallback defines the rules DiffUtil uses to determine
     * whether two {@link WeightEntry} items represent the same record and
     * whether their displayed content has changed.
     *
     * <p>Two entries are considered the <em>same item</em> if they share the
     * same database ID. They are considered to have the <em>same content</em>
     * if their date and weight values are also identical.</p>
     */
    private static class WeightEntryDiffCallback extends DiffUtil.Callback {

        private final List<WeightEntry> oldList;
        private final List<WeightEntry> newList;

        /**
         * Constructs a new WeightEntryDiffCallback.
         *
         * @param oldList the previous list before the update
         * @param newList the new list after the update
         */
        WeightEntryDiffCallback(List<WeightEntry> oldList, List<WeightEntry> newList) {
            this.oldList = oldList;
            this.newList = newList;
        }

        @Override
        public int getOldListSize() { return oldList.size(); }

        @Override
        public int getNewListSize() { return newList.size(); }

        /**
         * Returns true if the two items at the given positions represent the
         * same database record (same ID), regardless of whether content changed.
         */
        @Override
        public boolean areItemsTheSame(int oldPos, int newPos) {
            return oldList.get(oldPos).getId() == newList.get(newPos).getId();
        }

        /**
         * Returns true if the two items have identical content — same date
         * and same weight value. Called only when areItemsTheSame returns true.
         */
        @Override
        public boolean areContentsTheSame(int oldPos, int newPos) {
            WeightEntry oldEntry = oldList.get(oldPos);
            WeightEntry newEntry = newList.get(newPos);
            return oldEntry.getDate().equals(newEntry.getDate())
                    && Double.compare(oldEntry.getWeight(), newEntry.getWeight()) == 0;
        }
    }
}