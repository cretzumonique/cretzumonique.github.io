package com.example.weighttracker_monicacretu_projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * LoginActivity handles user authentication and new account registration.
 *
 * <p>This is the launcher activity of the Weight Tracker application. Users
 * must successfully log in before accessing the main weight tracking screen.
 * New users can register an account directly from this screen.</p>
 *
 * <p>Enhancement notes (CS 499 Milestone Two):
 * <ul>
 *   <li>Added maximum length validation for username and password fields</li>
 *   <li>Added minimum length enforcement for password security</li>
 *   <li>Added Javadoc to all methods</li>
 *   <li>Extracted validation logic into a dedicated helper method</li>
 * </ul>
 * </p>
 *
 * @author Monica Cretu
 * @version 2.0
 */
public class LoginActivity extends AppCompatActivity {

    // ── Constants ─────────────────────────────────────────────────────────────

    /** Maximum allowed length for a username. */
    private static final int MAX_USERNAME_LENGTH = 30;

    /** Minimum allowed length for a password. */
    private static final int MIN_PASSWORD_LENGTH = 6;

    /** Maximum allowed length for a password. */
    private static final int MAX_PASSWORD_LENGTH = 50;

    // ── UI Components ─────────────────────────────────────────────────────────

    private EditText       editUsername;
    private EditText       editPassword;
    private Button         buttonLogin;
    private Button         buttonRegister;
    private DatabaseHelper databaseHelper;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    /**
     * Initializes the activity, connects UI components, initializes the database
     * helper, and registers click listeners for Login and Register buttons.
     *
     * @param savedInstanceState the previously saved instance state, or null
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Connect UI elements
        editUsername   = findViewById(R.id.editUsername);
        editPassword   = findViewById(R.id.editPassword);
        buttonLogin    = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Login button click listener
        buttonLogin.setOnClickListener(v -> attemptLogin());

        // Register button click listener
        buttonRegister.setOnClickListener(v -> attemptRegistration());
    }

    // ── Authentication Logic ──────────────────────────────────────────────────

    /**
     * Attempts to log in with the credentials entered in the username and
     * password fields.
     *
     * <p>Validates that fields are non-empty and within length limits before
     * querying the database. Navigates to {@link MainActivity} on success.</p>
     */
    private void attemptLogin() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (!validateInputFields(username, password)) {
            return;
        }

        if (databaseHelper.checkUser(username, password)) {
            // Login successful — navigate to main screen and close login
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Invalid username or password.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Attempts to register a new account with the credentials entered in the
     * username and password fields.
     *
     * <p>Validates input fields, checks that the username is not already taken,
     * and inserts the new user record into the database. Displays confirmation
     * on success and an error message on failure.</p>
     */
    private void attemptRegistration() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (!validateInputFields(username, password)) {
            return;
        }

        // Check for duplicate username
        if (databaseHelper.usernameExists(username)) {
            Toast.makeText(this, "Username already exists. Please choose another.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Attempt to insert new user
        if (databaseHelper.addUser(username, password)) {
            Toast.makeText(this, "Account created successfully! Please log in.",
                    Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Registration failed. Please try again.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // ── Validation ────────────────────────────────────────────────────────────

    /**
     * Validates the username and password fields against the following rules:
     * <ul>
     *   <li>Neither field may be empty</li>
     *   <li>Username must not exceed {@value #MAX_USERNAME_LENGTH} characters</li>
     *   <li>Password must be at least {@value #MIN_PASSWORD_LENGTH} characters</li>
     *   <li>Password must not exceed {@value #MAX_PASSWORD_LENGTH} characters</li>
     * </ul>
     *
     * <p>Displays a Toast message describing the first validation failure found.</p>
     *
     * @param username the username string to validate
     * @param password the password string to validate
     * @return {@code true} if all validations pass; {@code false} otherwise
     */
    private boolean validateInputFields(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password.",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        if (username.length() > MAX_USERNAME_LENGTH) {
            Toast.makeText(this,
                    "Username must be " + MAX_USERNAME_LENGTH + " characters or fewer.",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password.length() < MIN_PASSWORD_LENGTH) {
            Toast.makeText(this,
                    "Password must be at least " + MIN_PASSWORD_LENGTH + " characters.",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password.length() > MAX_PASSWORD_LENGTH) {
            Toast.makeText(this,
                    "Password must be " + MAX_PASSWORD_LENGTH + " characters or fewer.",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}