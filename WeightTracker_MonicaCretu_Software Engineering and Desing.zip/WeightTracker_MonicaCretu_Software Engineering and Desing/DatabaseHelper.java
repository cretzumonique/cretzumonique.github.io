package com.example.weighttracker_monicacretu_projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DatabaseHelper manages all SQLite database operations for the Weight Tracker app.
 *
 * <p>This class extends {@link SQLiteOpenHelper} and provides a centralized
 * interface for all create, read, update, and delete (CRUD) operations across
 * three database tables: users, weights, and goal_weight.</p>
 *
 * <p>Enhancement notes (CS 499 Milestone Two):
 * <ul>
 *   <li>Added getMostRecentWeight() to support the progress dashboard</li>
 *   <li>Added getFirstWeight() to calculate progress percentage from baseline</li>
 *   <li>Added getSmsPhoneNumber() and saveSmsPhoneNumber() to support
 *       automatic goal-reached SMS triggering from MainActivity</li>
 *   <li>Added sms_settings table to persist the user's phone number</li>
 *   <li>Added comprehensive Javadoc to all methods</li>
 *   <li>Added NOT NULL constraints to critical columns</li>
 * </ul>
 * </p>
 *
 * <p><strong>Known limitation:</strong> Passwords are currently stored as
 * plaintext. A future enhancement (Milestone Four) will migrate this to
 * BCrypt hashing via Android Room.</p>
 *
 * @author Monica Cretu
 * @version 2.0
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // ── Database Configuration ────────────────────────────────────────────────

    /** The name of the SQLite database file. */
    private static final String DATABASE_NAME = "WeightTracker.db";

    /** Increment this value when the schema changes to trigger onUpgrade. */
    private static final int DATABASE_VERSION = 2;

    // ── Users Table ───────────────────────────────────────────────────────────

    private static final String TABLE_USERS    = "users";
    private static final String COL_USER_ID    = "id";
    private static final String COL_USERNAME   = "username";
    private static final String COL_PASSWORD   = "password";

    // ── Weights Table ─────────────────────────────────────────────────────────

    private static final String TABLE_WEIGHTS  = "weights";
    private static final String COL_WEIGHT_ID  = "id";
    private static final String COL_DATE       = "date";
    private static final String COL_WEIGHT     = "weight";

    // ── Goal Weight Table ─────────────────────────────────────────────────────

    private static final String TABLE_GOAL     = "goal_weight";
    private static final String COL_GOAL_ID    = "id";
    private static final String COL_GOAL       = "goal";

    // ── SMS Settings Table ────────────────────────────────────────────────────

    /** Table for storing the user's saved SMS notification phone number. */
    private static final String TABLE_SMS      = "sms_settings";
    private static final String COL_SMS_ID     = "id";
    private static final String COL_SMS_PHONE  = "phone_number";

    // ── Constructor ───────────────────────────────────────────────────────────

    /**
     * Constructs a new DatabaseHelper instance.
     *
     * @param context the application context used to open or create the database
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // ── Schema Creation ───────────────────────────────────────────────────────

    /**
     * Called when the database is created for the first time.
     * Creates all required tables with appropriate column types and constraints.
     *
     * @param db the database instance being created
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Users table — stores login credentials
        // NOTE: password stored as plaintext pending BCrypt migration in Milestone Four
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID   + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME  + " TEXT NOT NULL UNIQUE, "
                + COL_PASSWORD  + " TEXT NOT NULL)");

        // Weights table — stores daily weight log entries
        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " ("
                + COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_DATE      + " TEXT NOT NULL, "
                + COL_WEIGHT    + " REAL NOT NULL)");

        // Goal weight table — stores a single goal weight value
        db.execSQL("CREATE TABLE " + TABLE_GOAL + " ("
                + COL_GOAL_ID   + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_GOAL      + " REAL NOT NULL)");

        // SMS settings table — stores the user's notification phone number
        db.execSQL("CREATE TABLE " + TABLE_SMS + " ("
                + COL_SMS_ID    + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_SMS_PHONE + " TEXT)");
    }

    /**
     * Called when the database version number changes. Drops all existing tables
     * and recreates them. Note: this is a destructive migration strategy.
     * A non-destructive migration approach is planned for the Milestone Four
     * database enhancement using Android Room Migration objects.
     *
     * @param db         the database instance being upgraded
     * @param oldVersion the previous database version number
     * @param newVersion the new database version number
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SMS);
        onCreate(db);
    }

    // ── User Operations ───────────────────────────────────────────────────────

    /**
     * Verifies whether a username and password pair match a record in the users table.
     *
     * <p><strong>Security note:</strong> Passwords are currently compared as
     * plaintext. BCrypt hashing is planned for Milestone Four.</p>
     *
     * @param username the username to look up
     * @param password the plaintext password to verify
     * @return {@code true} if a matching record exists; {@code false} otherwise
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db     = this.getReadableDatabase();
        Cursor         cursor = db.query(
                TABLE_USERS, null,
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /**
     * Checks whether a username already exists in the users table.
     * Used during registration to prevent duplicate accounts.
     *
     * @param username the username to check for existence
     * @return {@code true} if the username is already taken; {@code false} otherwise
     */
    public boolean usernameExists(String username) {
        SQLiteDatabase db     = this.getReadableDatabase();
        Cursor         cursor = db.query(
                TABLE_USERS, null,
                COL_USERNAME + "=?",
                new String[]{username},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /**
     * Inserts a new user record into the users table.
     *
     * @param username the new user's username; must not be null or empty
     * @param password the new user's plaintext password; must not be null or empty
     * @return {@code true} if the insert succeeded; {@code false} if it failed
     */
    public boolean addUser(String username, String password) {
        SQLiteDatabase db     = this.getWritableDatabase();
        ContentValues  values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // ── Weight Entry Operations ───────────────────────────────────────────────

    /**
     * Inserts a new weight entry into the weights table.
     *
     * @param date   the date string for this entry (format: MM/dd/yyyy)
     * @param weight the weight value in pounds; expected range 50–700
     * @return {@code true} if the insert succeeded; {@code false} if it failed
     */
    public boolean addWeight(String date, double weight) {
        SQLiteDatabase db     = this.getWritableDatabase();
        ContentValues  values = new ContentValues();
        values.put(COL_DATE,   date);
        values.put(COL_WEIGHT, weight);
        long result = db.insert(TABLE_WEIGHTS, null, values);
        return result != -1;
    }

    /**
     * Deletes a weight entry from the weights table by its unique row ID.
     *
     * @param id the primary key ID of the entry to delete
     */
    public void deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHTS,
                COL_WEIGHT_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    /**
     * Updates the weight value of an existing entry identified by its row ID.
     *
     * @param id        the primary key ID of the entry to update
     * @param newWeight the replacement weight value in pounds
     */
    public void updateWeight(int id, double newWeight) {
        SQLiteDatabase db     = this.getWritableDatabase();
        ContentValues  values = new ContentValues();
        values.put(COL_WEIGHT, newWeight);
        db.update(TABLE_WEIGHTS, values,
                COL_WEIGHT_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    /**
     * Retrieves all weight entries ordered by date string descending.
     *
     * <p>The caller is responsible for closing the returned Cursor after use.</p>
     *
     * @return a {@link Cursor} over all rows in the weights table,
     *         or {@code null} if the database could not be opened
     */
    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM " + TABLE_WEIGHTS
                        + " ORDER BY " + COL_DATE + " DESC",
                null);
    }

    /**
     * Retrieves the most recently logged weight value.
     *
     * <p>Used by the progress dashboard to display the user's current weight.</p>
     *
     * @return the most recent weight value in pounds, or {@code -1} if no
     *         entries exist
     */
    public double getMostRecentWeight() {
        SQLiteDatabase db     = this.getReadableDatabase();
        Cursor         cursor = db.rawQuery(
                "SELECT " + COL_WEIGHT + " FROM " + TABLE_WEIGHTS
                        + " ORDER BY " + COL_DATE + " DESC LIMIT 1",
                null);
        if (cursor.moveToFirst()) {
            double weight = cursor.getDouble(0);
            cursor.close();
            return weight;
        }
        cursor.close();
        return -1;
    }

    /**
     * Retrieves the first (oldest) logged weight value.
     *
     * <p>Used as the baseline starting point for progress percentage
     * calculations in the dashboard.</p>
     *
     * @return the oldest weight value in pounds, or {@code -1} if no
     *         entries exist
     */
    public double getFirstWeight() {
        SQLiteDatabase db     = this.getReadableDatabase();
        Cursor         cursor = db.rawQuery(
                "SELECT " + COL_WEIGHT + " FROM " + TABLE_WEIGHTS
                        + " ORDER BY " + COL_DATE + " ASC LIMIT 1",
                null);
        if (cursor.moveToFirst()) {
            double weight = cursor.getDouble(0);
            cursor.close();
            return weight;
        }
        cursor.close();
        return -1;
    }

    // ── Goal Weight Operations ────────────────────────────────────────────────

    /**
     * Saves or replaces the user's goal weight. Only one goal value is stored
     * at a time; any existing goal is deleted before the new value is inserted.
     *
     * @param goal the goal weight in pounds to save
     */
    public void setGoalWeight(double goal) {
        SQLiteDatabase db     = this.getWritableDatabase();
        db.delete(TABLE_GOAL, null, null);
        ContentValues  values = new ContentValues();
        values.put(COL_GOAL, goal);
        db.insert(TABLE_GOAL, null, values);
    }

    /**
     * Retrieves the currently stored goal weight.
     *
     * @return the goal weight in pounds, or {@code -1} if no goal has been set
     */
    public double getGoalWeight() {
        SQLiteDatabase db     = this.getReadableDatabase();
        Cursor         cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_GOAL, null);
        if (cursor.moveToFirst()) {
            double goal = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_GOAL));
            cursor.close();
            return goal;
        }
        cursor.close();
        return -1;
    }

    // ── SMS Settings Operations ───────────────────────────────────────────────

    /**
     * Saves or replaces the user's SMS notification phone number.
     * Only one phone number is stored at a time.
     *
     * @param phoneNumber the phone number string to save; must not be null
     */
    public void saveSmsPhoneNumber(String phoneNumber) {
        SQLiteDatabase db     = this.getWritableDatabase();
        db.delete(TABLE_SMS, null, null);
        ContentValues  values = new ContentValues();
        values.put(COL_SMS_PHONE, phoneNumber);
        db.insert(TABLE_SMS, null, values);
    }

    /**
     * Retrieves the stored SMS notification phone number.
     *
     * @return the saved phone number string, or {@code null} if none has been saved
     */
    public String getSmsPhoneNumber() {
        SQLiteDatabase db     = this.getReadableDatabase();
        Cursor         cursor = db.rawQuery(
                "SELECT " + COL_SMS_PHONE + " FROM " + TABLE_SMS, null);
        if (cursor.moveToFirst()) {
            String phone = cursor.getString(0);
            cursor.close();
            return phone;
        }
        cursor.close();
        return null;
    }
}
