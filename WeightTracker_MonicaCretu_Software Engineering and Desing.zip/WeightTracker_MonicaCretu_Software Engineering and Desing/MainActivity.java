package com.example.weighttracker_monicacretu_projecttwo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity is the primary screen of the Weight Tracker application.
 *
 * <p>This activity displays the user's weight entry history in a scrollable
 * RecyclerView, shows current progress toward a goal weight via a ProgressBar
 * dashboard, and provides navigation to add entries, set a goal, and manage
 * SMS notification settings.</p>
 *
 * <p>Enhancement notes (CS 499 Milestone Two):
 * <ul>
 *   <li>Added progress dashboard with ProgressBar and summary TextViews</li>
 *   <li>Added dirty flag pattern to avoid redundant database reloads on resume</li>
 *   <li>Wired sendGoalReachedSms to trigger automatically when goal is met</li>
 *   <li>Added input validation with numeric range enforcement in editWeight</li>
 *   <li>Added try-catch around Double.parseDouble and cursor operations</li>
 *   <li>Added null check on Cursor before iteration</li>
 *   <li>Added Javadoc to all methods</li>
 * </ul>
 * </p>
 *
 * @author Monica Cretu
 * @version 2.0
 */
public class MainActivity extends AppCompatActivity {

    // ── Constants ────────────────────────────────────────────────────────────

    /** Minimum acceptable weight value in pounds. */
    private static final double MIN_WEIGHT_LBS = 50.0;

    /** Maximum acceptable weight value in pounds. */
    private static final double MAX_WEIGHT_LBS = 700.0;

    // ── UI Components ─────────────────────────────────────────────────────────

    private RecyclerView recyclerViewWeights;
    private TextView textGoalWeight;
    private TextView textCurrentWeight;
    private TextView textProgressSummary;
    private ProgressBar progressBarGoal;
    private Button buttonAddWeight;
    private Button buttonSetGoal;
    private Button buttonSmsSettings;

    // ── Data and Helpers ──────────────────────────────────────────────────────

    private DatabaseHelper databaseHelper;
    private WeightAdapter weightAdapter;
    private List<WeightEntry> weightList;

    /**
     * Dirty flag: set to true when data has changed and a reload is needed.
     * Prevents unnecessary full database reloads on every onResume cycle.
     */
    private boolean dataChanged = true;

    /** SMS permission launcher using the Activity Result API. */
    private ActivityResultLauncher<String> smsPermissionLauncher;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    /**
     * Initializes the activity, connects UI components, sets up the RecyclerView,
     * registers the SMS permission launcher, and loads initial data.
     *
     * @param savedInstanceState the previously saved instance state, or null
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        initDatabase();
        initRecyclerView();
        initSmsPermissionLauncher();
        initButtonListeners();

        // Request SMS permission on first launch
        checkSmsPermission();

        // Initial data load
        loadWeights();
        loadGoalWeight();
        updateProgressDashboard();
    }

    /**
     * Reloads data only when the dirty flag indicates a change has occurred
     * since the last load. This avoids a redundant full database scan every
     * time the user navigates back to this screen.
     */
    @Override
    protected void onResume() {
        super.onResume();
        if (dataChanged) {
            loadWeights();
            loadGoalWeight();
            updateProgressDashboard();
            dataChanged = false;
        }
    }

    // ── Initialization Helpers ────────────────────────────────────────────────

    /**
     * Connects all UI element references via findViewById.
     */
    private void initViews() {
        recyclerViewWeights  = findViewById(R.id.recyclerViewWeights);
        textGoalWeight       = findViewById(R.id.textGoalWeight);
        textCurrentWeight    = findViewById(R.id.textCurrentWeight);
        textProgressSummary  = findViewById(R.id.textProgressSummary);
        progressBarGoal      = findViewById(R.id.progressBarGoal);
        buttonAddWeight      = findViewById(R.id.buttonAddWeight);
        buttonSetGoal        = findViewById(R.id.buttonSetGoal);
        buttonSmsSettings    = findViewById(R.id.buttonSmsSettings);
    }

    /**
     * Initializes the DatabaseHelper instance and the weight entry list.
     */
    private void initDatabase() {
        databaseHelper = new DatabaseHelper(this);
        weightList     = new ArrayList<>();
    }

    /**
     * Configures the RecyclerView with a LinearLayoutManager, divider decoration,
     * and a WeightAdapter that receives delete and edit callbacks.
     */
    private void initRecyclerView() {
        weightAdapter = new WeightAdapter(weightList, this::deleteWeight, this::editWeight);
        recyclerViewWeights.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewWeights.addItemDecoration(
                new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerViewWeights.setAdapter(weightAdapter);
    }

    /**
     * Registers the SMS permission result launcher. Updates the user via Toast
     * to confirm whether the permission was granted or denied.
     */
    private void initSmsPermissionLauncher() {
        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), isGranted -> {
                    if (isGranted) {
                        Toast.makeText(this, "SMS notifications enabled",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this,
                                "SMS denied. App will work without notifications.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    /**
     * Attaches click listeners to the Add Weight, Set Goal, and SMS Settings buttons.
     * Sets the dirty flag to true before navigating away so that data reloads
     * correctly on return.
     */
    private void initButtonListeners() {
        buttonAddWeight.setOnClickListener(v -> {
            dataChanged = true;
            startActivity(new Intent(this, AddWeightActivity.class));
        });

        buttonSetGoal.setOnClickListener(v -> {
            dataChanged = true;
            Intent intent = new Intent(this, AddWeightActivity.class);
            intent.putExtra("mode", "goal");
            startActivity(intent);
        });

        buttonSmsSettings.setOnClickListener(v ->
                startActivity(new Intent(this, SmsSettingsActivity.class)));
    }

    // ── Data Loading ──────────────────────────────────────────────────────────

    /**
     * Loads all weight entries from the database into the RecyclerView.
     *
     * <p>Performs a null check on the returned Cursor and wraps column index
     * access in a try-catch to prevent crashes from unexpected schema changes.</p>
     */
    private void loadWeights() {
        weightList.clear();
        Cursor cursor = databaseHelper.getAllWeights();

        if (cursor == null) {
            weightAdapter.updateList(weightList);
            return;
        }

        try {
            if (cursor.moveToFirst()) {
                do {
                    int    id     = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                    String date   = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                    double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
                    weightList.add(new WeightEntry(id, date, weight));
                } while (cursor.moveToNext());
            }
        } catch (IllegalArgumentException e) {
            Toast.makeText(this, "Error reading weight data.", Toast.LENGTH_SHORT).show();
        } finally {
            cursor.close();
        }

        weightAdapter.updateList(weightList);
    }

    /**
     * Loads the stored goal weight from the database and updates the goal TextView.
     * Displays "Not set" when no goal has been recorded.
     */
    private void loadGoalWeight() {
        double goal = databaseHelper.getGoalWeight();
        if (goal != -1) {
            textGoalWeight.setText(String.format("Goal Weight: %.1f lbs", goal));
        } else {
            textGoalWeight.setText("Goal Weight: Not set");
        }
    }

    // ── Progress Dashboard ────────────────────────────────────────────────────

    /**
     * Updates the progress dashboard section of the UI.
     *
     * <p>Displays the most recent weight entry, calculates the percentage of
     * progress toward the goal weight, and updates the ProgressBar accordingly.
     * If no entries or no goal exist, the dashboard displays informative
     * placeholder text and hides the ProgressBar.</p>
     */
    private void updateProgressDashboard() {
        double goal    = databaseHelper.getGoalWeight();
        double current = databaseHelper.getMostRecentWeight();

        if (current == -1) {
            textCurrentWeight.setText("Current Weight: No entries yet");
            textProgressSummary.setText("Log your first weight entry to see progress.");
            progressBarGoal.setVisibility(View.GONE);
            return;
        }

        textCurrentWeight.setText(String.format("Current Weight: %.1f lbs", current));

        if (goal == -1) {
            textProgressSummary.setText("Set a goal weight to track your progress.");
            progressBarGoal.setVisibility(View.GONE);
            return;
        }

        // Calculate progress percentage toward goal
        double startWeight = databaseHelper.getFirstWeight();
        if (startWeight == -1 || startWeight == goal) {
            progressBarGoal.setVisibility(View.GONE);
            textProgressSummary.setText("Keep logging to see your progress trend.");
            return;
        }

        double totalChange  = Math.abs(startWeight - goal);
        double achieved     = Math.abs(startWeight - current);
        int    progressPct  = (int) Math.min(100, (achieved / totalChange) * 100);

        progressBarGoal.setVisibility(View.VISIBLE);
        progressBarGoal.setProgress(progressPct);
        textProgressSummary.setText(String.format(
                "Progress toward goal: %d%% (%.1f lbs to go)",
                progressPct, Math.abs(current - goal)));

        // Trigger SMS if goal has been reached
        if (current <= goal) {
            String savedPhone = databaseHelper.getSmsPhoneNumber();
            if (savedPhone != null && !savedPhone.isEmpty()) {
                sendGoalReachedSms(savedPhone);
            }
        }
    }

    // ── Entry Management ──────────────────────────────────────────────────────

    /**
     * Deletes a weight entry from the database by its unique ID, refreshes
     * the list, and updates the progress dashboard.
     *
     * @param id the database ID of the weight entry to delete
     */
    private void deleteWeight(int id) {
        databaseHelper.deleteWeight(id);
        loadWeights();
        updateProgressDashboard();
        Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
    }

    /**
     * Displays an AlertDialog allowing the user to edit an existing weight entry.
     *
     * <p>Input is validated for the following conditions before saving:
     * <ul>
     *   <li>Field must not be empty</li>
     *   <li>Value must be a valid decimal number (NumberFormatException handled)</li>
     *   <li>Value must be within the range of {@value #MIN_WEIGHT_LBS} to
     *       {@value #MAX_WEIGHT_LBS} pounds</li>
     * </ul>
     * </p>
     *
     * @param entry the {@link WeightEntry} to be edited
     */
    private void editWeight(WeightEntry entry) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Weight Entry");
        builder.setMessage(String.format(
                "Current value: %.1f lbs on %s", entry.getWeight(), entry.getDate()));

        final EditText input = new EditText(this);
        input.setText(String.valueOf(entry.getWeight()));
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setHint(String.format("Enter weight (%.0f–%.0f lbs)",
                MIN_WEIGHT_LBS, MAX_WEIGHT_LBS));
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newWeightStr = input.getText().toString().trim();

            // Validation: field must not be empty
            if (newWeightStr.isEmpty()) {
                Toast.makeText(this, "Please enter a weight value.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Validation: must be a valid number
            double newWeight;
            try {
                newWeight = Double.parseDouble(newWeightStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number. Please enter a valid weight.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Validation: must be within acceptable range
            if (newWeight < MIN_WEIGHT_LBS || newWeight > MAX_WEIGHT_LBS) {
                Toast.makeText(this,
                        String.format("Weight must be between %.0f and %.0f lbs.",
                                MIN_WEIGHT_LBS, MAX_WEIGHT_LBS),
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // All validations passed — save to database
            databaseHelper.updateWeight(entry.getId(), newWeight);
            loadWeights();
            updateProgressDashboard();
            Toast.makeText(this, "Weight updated successfully.", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // ── SMS ───────────────────────────────────────────────────────────────────

    /**
     * Checks whether the SEND_SMS permission has been granted and requests it
     * via the registered permission launcher if not.
     */
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    /**
     * Sends a congratulatory SMS message to the specified phone number when the
     * user's logged weight meets or falls below their goal weight.
     *
     * <p>This method is only called when:
     * <ul>
     *   <li>The SEND_SMS permission has been granted</li>
     *   <li>A valid phone number has been saved in SMS settings</li>
     *   <li>The most recent weight entry is at or below the goal weight</li>
     * </ul>
     * </p>
     *
     * @param phoneNumber the destination phone number for the SMS message
     */
    public void sendGoalReachedSms(String phoneNumber) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(
                    phoneNumber, null,
                    "Congratulations! You reached your goal weight!",
                    null, null);
            Toast.makeText(this, "Goal reached! SMS sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not send SMS.", Toast.LENGTH_SHORT).show();
        }
    }
}